/////bmf-v2_2////

class safety
{
	file = "bso\safe";
	class safety {};
	class gameOn {};
	class safeZone {};
	class unsetSafety {};
	class timeSlow {};
};
