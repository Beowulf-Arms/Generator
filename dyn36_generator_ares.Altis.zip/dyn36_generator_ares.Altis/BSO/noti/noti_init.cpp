/////bmf-v2_2////
class CfgNotifications
{
	class BSOSafeStart
	{
		title = "SafeStart"; // Tile displayed as text on black background. Filled by arguments.
		iconPicture = "BSO\noti\bso_logo.paa"; // Small icon displayed in left part. Colored by "color", filled by arguments.
		description = "%1"; // Brief description displayed as structured text. Colored by "color", filled by arguments.

	};
	class BSOMission
	{
		title = "Mission Status"; // Tile displayed as text on black background. Filled by arguments.
		iconPicture = "BSO\noti\bso_logo.paa"; // Small icon displayed in left part. Colored by "color", filled by arguments.
		description = "%1"; // Brief description displayed as structured text. Colored by "color", filled by arguments.

	};	
	
};	
