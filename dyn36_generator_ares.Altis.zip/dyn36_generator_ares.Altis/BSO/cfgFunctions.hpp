/////bmf-v2_2////

class bso
{
	class main
	{
		file = "bso";
		class acreApplyLanguages {};
		class acreCustomLanguages {};
		class addJipTp {};
	};
	#include "safe\cfgFunctions.hpp"
};
