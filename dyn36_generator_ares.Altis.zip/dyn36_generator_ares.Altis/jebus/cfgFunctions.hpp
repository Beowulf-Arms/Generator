class jebus
{
	class main
	{
		file = "jebus";
		class main {};
		class enemyInRadius {};
		class playerInRadius {};
		class pilotKill {};
		class reduce {};
		class cache {};
		class saveWaypoints {};
		class applyWaypoints {};
	};

};
